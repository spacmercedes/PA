create procedure clonare(tb_veche varchar2, tb_name varchar2)
is
begin
    execute immediate 'CREATE TABLE ' || tb_name || ' AS SELECT * FROM ' || tb_veche;
    commit;
end clonare;
/

