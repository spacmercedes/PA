create TYPE BODY individ IS
 
    CONSTRUCTOR FUNCTION individ(p_nume VARCHAR2, p_prenume VARCHAR2, p_gender VARCHAR2, p_data DATE)
        RETURN SELF AS RESULT AS 
    BEGIN
        self.nume := p_nume;
        self.prenume := p_prenume;

        IF p_gender = 'm' THEN
            self.cnp := 5;
        ELSIF p_gender = 'f' THEN
            self.cnp := 6;
        END IF;

        self.cnp := self.cnp * 100 + TO_CHAR(EXTRACT(DAY FROM TO_DATE(p_data, 'DD-MM-YY')));
        self.cnp := self.cnp * 100 + TO_CHAR(EXTRACT(MONTH FROM TO_DATE(p_data, 'DD-MM-YY')) -20);
        self.cnp := self.cnp * 100 + TO_CHAR(EXTRACT(YEAR FROM TO_DATE(p_data, 'DD-MM-YY')));

        RETURN;

    END;

    ORDER MEMBER FUNCTION comparare(p_individ individ) 
        RETURN NUMBER IS
    BEGIN
        IF MOD(self.cnp, 100) > MOD(p_individ.cnp, 100) THEN 
            RETURN 1;
        END IF;
        IF MOD(self.cnp, 100) < MOD(p_individ.cnp, 100) THEN
            RETURN 0;
        END IF;
        IF MOD(self.cnp/100, 100) > MOD(p_individ.cnp/100, 100) THEN 
            RETURN 1;
        END IF;
        IF MOD(self.cnp/100, 100) < MOD(p_individ.cnp/100, 100) THEN
            RETURN 0;
        END IF;
        IF MOD(self.cnp/10000, 100) > MOD(p_individ.cnp/10000, 100) THEN
            RETURN 1;
        END IF;
        IF MOD(self.cnp/10000, 100) < MOD(p_individ.cnp/10000, 100) THEN
            RETURN 0;
        END IF;

        RETURN 2; -- aceeasi data de nastere
    END;   

    MEMBER PROCEDURE output IS
       BEGIN
           DBMS_OUTPUT.PUT_LINE(nume || ' ' || prenume || ' CNP : ' || cnp);
       END output;
END;
/

