create FUNCTION calculeaza_media(p_nume studenti.nume%TYPE, p_prenume studenti.prenume%TYPE)

RETURN FLOAT AS
     CURSOR v_student  IS SELECT * FROM studenti WHERE TRIM(studenti.nume) = TRIM(p_nume) AND TRIM(studenti.prenume) = TRIM(p_prenume);
     v_id studenti.id%TYPE;
     v_medie float;
     v_note int;
BEGIN 
    OPEN v_student;

    IF v_student%ROWCOUNT != 0 THEN
         LOOP
            FETCH v_student.id INTO v_id;
            SELECT * INTO v_note FROM (SELECT COUNT(n.valoare) FROM studenti s JOIN note n on s.id = n.id_student WHERE s.id = v_id GROUP BY s.id);
            IF v_note = 0 THEN
                   DBMS_OUTPUT.PUT_LINE('Studentul ' || p_nume || ' ' || p_prenume || ' nu are nicio nota inregistrata' );
                   RETURN 0;
        ELSE 
            SELECT AVG(n.valoare) INTO v_medie FROM studenti s JOIN note n on s.id = n.id_student WHERE s.id = v_id GROUP BY s.id;
            RETURN v_medie;
                END IF;
         END LOOP;
     ELSE
         DBMS_OUTPUT.PUT_LINE('Studentul ' || p_nume || ' ' || p_prenume || ' nu exista in baza de date ' );
         RETURN 0;
    END IF;
    CLOSE v_student;  
END calculeaza_media;

DECLARE 
  TYPE stud_nume IS VARRAY(6) OF studenti.nume%TYPE;
  nume_studenti stud_nume;
  TYPE stud_prenume IS VARRAY(6) OF studenti.prenume%TYPE;
  prenume_studenti stud_prenume;
BEGIN
  nume_studenti := stud_nume('Anghelina', 'Irimia', 'Iovu', 'Nume1', 'Nume2', 'Nume3');
  prenume_studenti := stud_prenume('Ioana', 'Alin', 'Adrian Mihail', 'Prenume1', 'Prenume2', 'Prenume3');
    FOR i IN nume_studenti.FIRST..nume_studenti.LAST LOOP
     DBMS_OUTPUT.PUT_LINE('Media studentului ' || nume_studenti(i) || prenume_studenti(i) || ' este ' || calculeaza_media(nume_studenti(i), prenume_studenti(i)));
   END LOOP;
END;
/

