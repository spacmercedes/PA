create TYPE BODY persoana IS
 
    CONSTRUCTOR FUNCTION persoana(p_nume VARCHAR2, p_prenume VARCHAR2, p_gender VARCHAR2, p_data DATE)
        RETURN SELF AS RESULT AS 
    BEGIN
        self.nume := p_nume;
        self.prenume := p_prenume;

        IF p_gender = 'm' THEN
            self.cnp := 5;
        ELSIF p_gender = 'f' THEN
            self.cnp := 6;
        END IF;

        self.cnp := self.cnp * 100 + TO_CHAR(EXTRACT(DAY FROM TO_DATE(p_data, 'DD-MM-YY')));
        self.cnp := self.cnp * 100 + TO_CHAR(EXTRACT(MONTH FROM TO_DATE(p_data, 'DD-MM-YY')) -20);
        self.cnp := self.cnp * 100 + TO_CHAR(EXTRACT(YEAR FROM TO_DATE(p_data, 'DD-MM-YY')));

        RETURN;

    END;

    ORDER MEMBER FUNCTION comparare(p_persoana persoana) 
        RETURN NUMBER IS
    BEGIN
        IF MOD(self.cnp, 100) > MOD(p_persoana.cnp, 100) THEN 
            RETURN 1;
        END IF;
        IF MOD(self.cnp, 100) < MOD(p_persoana.cnp, 100) THEN
            RETURN 0;
        END IF;
        IF MOD(self.cnp/100, 100) > MOD(p_persoana.cnp/100, 100) THEN 
            RETURN 1;
        END IF;
        IF MOD(self.cnp/100, 100) < MOD(p_persoana.cnp/100, 100) THEN
            RETURN 0;
        END IF;
        IF MOD(self.cnp/10000, 100) > MOD(p_persoana.cnp/10000, 100) THEN
            RETURN 1;
        END IF;
        IF MOD(self.cnp/10000, 100) < MOD(p_persoana.cnp/10000, 100) THEN
            RETURN 0;
        END IF;

        RETURN 5;
    END;   

    MEMBER PROCEDURE afisare IS
       BEGIN
           DBMS_OUTPUT.PUT_LINE(' CNP : ' || cnp || ' ' ||  nume || ' ' || prenume );
       END afisare;
END;
/

