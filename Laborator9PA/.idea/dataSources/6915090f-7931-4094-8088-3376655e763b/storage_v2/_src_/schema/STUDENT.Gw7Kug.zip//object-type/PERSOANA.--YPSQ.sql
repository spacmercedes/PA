create TYPE persoana AS OBJECT(
    nume VARCHAR2(20),
    prenume VARCHAR2(20),
    cnp NUMBER(7),
    CONSTRUCTOR FUNCTION persoana(p_nume VARCHAR2, p_prenume VARCHAR2, p_gender VARCHAR2, p_data DATE) RETURN SELF AS RESULT,
    ORDER MEMBER FUNCTION comparare(p_persoana persoana) RETURN NUMBER,
    MEMBER PROCEDURE afisare ( SELF IN OUT NOCOPY persoana )
);
/

