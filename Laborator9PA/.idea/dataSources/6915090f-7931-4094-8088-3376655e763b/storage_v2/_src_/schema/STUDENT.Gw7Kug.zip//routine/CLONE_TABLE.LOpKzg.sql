create procedure clone_table (v_nume IN varchar2)
as
   v_cursor_id INTEGER;
   v_ok INTEGER;
   v_CreateTableString varchar2(100);
begin
  v_cursor_id := DBMS_SQL.OPEN_CURSOR;
  v_CreateTableString := 'CREATE TABLE ' || v_nume || 'new as select * from '||v_nume;
  DBMS_SQL.PARSE(v_cursor_id, v_CreateTAbleString, DBMS_SQL.NATIVE);
  v_ok := DBMS_SQL.EXECUTE(v_cursor_id);
  DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
end;
/

