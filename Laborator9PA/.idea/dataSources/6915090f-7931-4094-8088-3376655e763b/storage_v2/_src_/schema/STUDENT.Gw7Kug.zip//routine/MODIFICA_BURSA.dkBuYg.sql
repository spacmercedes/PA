create PROCEDURE modifica_bursa(p_val IN NUMBER := 0) AS
     v_lines INTEGER :=1;
     v_max studenti.bursa%TYPE := 0;
     v_bursa studenti.bursa%TYPE :=0;
     CURSOR bursieri IS
            SELECT s.nume, s.prenume, s.bursa FROM studenti s
            WHERE s.bursa is not null
    ;
BEGIN

       FOR v_student_linie IN bursieri LOOP
            UPDATE studenti
            SET bursa = bursa*1.1;
                v_lines := v_lines+1;
             v_bursa := v_student_linie.bursa;
             IF (v_bursa > v_max)
             THEN 
                    v_max := v_student_linie.bursa;
            END IF;
       EXIT WHEN v_max >= 2000;
       END LOOP; 
END modifica_bursa;
/

