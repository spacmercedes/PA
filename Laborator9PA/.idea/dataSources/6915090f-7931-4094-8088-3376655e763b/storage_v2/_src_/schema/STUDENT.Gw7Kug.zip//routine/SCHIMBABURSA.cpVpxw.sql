create PROCEDURE schimbaBursa(p_valoare IN NUMBER := 0) AS
    v_bursa studenti.bursa%TYPE :=0;
     v_maximValoare studenti.bursa%TYPE := 0;
     v_linie INTEGER :=1;   

    CURSOR studentiBursieri IS 
    SELECT id,nume,prenume,bursa FROM studenti WHERE bursa IS NOT NULL;

BEGIN
       FOR v_studentInfo IN studentiBursieri LOOP
            UPDATE studenti
            SET bursa = bursa*1.1;
                v_linie := v_linie+1;
             IF (v_bursa > v_maximValoare)
             THEN 
            v_maximValoare := v_studentInfo.bursa;
            END IF;
       EXIT WHEN v_maximValoare >= 2000;
       END LOOP; 
END schimbaBursa;
/

