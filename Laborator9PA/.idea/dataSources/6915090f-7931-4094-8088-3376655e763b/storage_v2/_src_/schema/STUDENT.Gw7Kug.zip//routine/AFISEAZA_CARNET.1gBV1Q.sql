create PROCEDURE afiseaza_carnet (IN_id_student IN studenti.id%TYPE)
IS
  v_CursorID NUMBER;--variabila careia i se atribuie valoarea de catre open cursor
  v_SelectRecords VARCHAR2(128);--SQL stocat ca sir pentru selectarea de valori
  v_NUMRows INTEGER;--numar de randuri prelucrate

  v_Nume VARCHAR2(100);
  v_Prenume VARCHAR2(100);
  v_Disciplina VARCHAR2(64);
  v_Profesor VARCHAR2(128);
  v_Nota NUMBER(2);
  v_Data_Examinarii DATE;

  v_indx INTEGER := 1;
BEGIN
  v_CursorID := DBMS_SQL.OPEN_CURSOR;--se deschide cursorul

  v_SelectRecords := 'SELECT * FROM S' || IN_id_student;

  DBMS_SQL.PARSE(v_CursorID,v_SelectRecords,DBMS_SQL.NATIVE);--depistarea erorilor sintactice(se analizeaza instructiunea SQL)

  DBMS_SQL.DEFINE_COLUMN(v_CursorID, 1, v_Nume, 100);
  DBMS_SQL.DEFINE_COLUMN(v_CursorID, 2, v_Prenume, 100);
  DBMS_SQL.DEFINE_COLUMN(v_CursorID, 3, v_Disciplina, 64);
  DBMS_SQL.DEFINE_COLUMN(v_CursorID, 4, v_Profesor, 128);
  DBMS_SQL.DEFINE_COLUMN(v_CursorID, 5, v_Nota);
  DBMS_SQL.DEFINE_COLUMN(v_CursorID, 6, v_Data_Examinarii);

  v_NUMRows := DBMS_SQL.EXECUTE(v_CursorID);--executarea instructiunii SQL

  DBMS_OUTPUT.PUT_LINE('    Carnet De Note: (' || IN_id_student || ')');
  DBMS_OUTPUT.PUT_LINE('#. Nume: Prenume: Disciplina : Profesor : Nota : Data Examinarii');

  LOOP
    IF DBMS_SQL.FETCH_ROWS(v_CursorID) = 0
      THEN
        EXIT;
    END IF;

    DBMS_SQL.COLUMN_VALUE(v_CursorID, 1, v_Nume);
    DBMS_SQL.COLUMN_VALUE(v_CursorID, 2, v_Prenume);
    DBMS_SQL.COLUMN_VALUE(v_CursorID, 3, v_Disciplina);
    DBMS_SQL.COLUMN_VALUE(v_CursorID, 4, v_Profesor);
    DBMS_SQL.COLUMN_VALUE(v_CursorID, 5, v_Nota);
    DBMS_SQL.COLUMN_VALUE(v_CursorID, 6, v_Data_Examinarii);

    DBMS_OUTPUT.PUT_LINE(v_indx || '. ' || v_Nume || ' : ' || v_Prenume || ' : ' || v_Disciplina || ' : ' || v_Profesor || ' : ' || v_Nota || ' : ' ||v_Data_Examinarii);

    v_indx := v_indx + 1;
  END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
    DBMS_SQL.CLOSE_CURSOR(v_CursorID);
END afiseaza_carnet;
/

