create FUNCTION get_count(IN_table VARCHAR2)  
RETURN NUMBER
IS
  l_count NUMBER;
  l_query VARCHAR2(200);

BEGIN 
  l_query := 'SELECT COUNT(*) FROM ' || IN_table; 
    EXECUTE IMMEDIATE l_query INTO l_count; 
  RETURN l_count;
END get_count;
/

