create TYPE pesoana AS OBJECT(

CNP NUMBER(7),
nume VARCHAR2(20),
prenume VARCHAR2(20),

CONSTRUCTOR FUNCTION persoana(p_nume VARCHAR2, p_prenume VARCHAR2, p_gen VARCHAR2, p_data DATE)
RETURN SELF AS RESULT,

ORDER MEMBER FUNCTION comparaDupaVarsta (p_persoana persoana) RETURN NUMBER,
MEMBER PROCEDURE output (SELF IN OUTPUT NO COPY persoana)

):

/

