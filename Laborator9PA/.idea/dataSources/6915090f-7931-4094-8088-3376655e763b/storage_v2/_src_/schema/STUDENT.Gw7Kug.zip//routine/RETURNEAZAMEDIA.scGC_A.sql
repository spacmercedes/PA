create FUNCTION returneazaMedia(p_nume studenti.nume%TYPE, p_prenume studenti.prenume%TYPE)

RETURN FLOAT AS
     v_nume studenti.nume%TYPE;
     v_prenume studenti.prenume%TYPE;
     v_linie studenti%ROWTYPE;
     v_mediaNote float;
     v_note int;
BEGIN 

   FOR v_linie IN (SELECT id,nume,prenume FROM studenti WHERE TRIM(studenti.nume) = TRIM(p_nume) AND TRIM(studenti.prenume) = TRIM(p_prenume))

         LOOP
         IF v_linie%ROWCOUNT != 0 THEN
            SELECT * INTO v_note FROM (SELECT COUNT(n.valoare) FROM studenti s JOIN note n on s.id = n.id_student WHERE s.id = v_id 
            GROUP BY s.id);
            IF v_note = 0 THEN
                   DBMS_OUTPUT.PUT_LINE(v_linie.nume || ' ' || v_linie.prenume || ' nu are note' );
                  RETURN 0;
        ELSE 
            SELECT AVG(n.valoare) INTO v_mediaNote FROM studenti s JOIN note n on s.id = n.id_student WHERE s.id = v_id
            GROUP BY s.id;
            RETURN v_mediaNote;
                END IF;

     ELSE
         DBMS_OUTPUT.PUT_LINE( v_linie.nume || ' ' || v_linie.prenume || ' nu exista ' );
         RETURN 0;
   END IF;
     END LOOP;
END returneazaMedia;
/

